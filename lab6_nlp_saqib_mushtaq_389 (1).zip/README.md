# Lab 6: NLP Fundamentals - Tokenization, Embeddings & Text Chunking
**Student:** Saqib Mushtaq Ahmed (Roll Number: 389)  
**Course:** AI Lab CS4944 (CLO3 - Apply)

## Directory Structure
- `lab6_search.py`: Core Retriever engine supporting TF-IDF and SentenceTransformers embeddings.
- `scenario1_handbook.py` to `scenario5_equipment.py`: Five practical scenario scripts with metadata filtering.
- `task1_tokens.py`: Comparison of Whitespace, Word-like Regex, and Subword Tokenization across 6 inputs.
- `guided_chatbot.py`: FAQ Chatbot implementation with confirmation flow.
- `task1_chatbot_check.py`: Verification assertions for FAQ Chatbot.
- `task2_chunks.py`: Word-window (overlap 0/10) and Sentence-aware chunking implementation.
- `corpus.json` & `queries.json`: Synthetic policy corpus (5 documents) and labeled evaluation queries (8 answerable + 2 unanswerable).
- `task3_retrieval.py`: Benchmark runner measuring Hit@3 and MRR@3 across 6 strategies and exporting `retrieval_log.csv`.
- `document_chatbot.py`: Interactive document evidence chatbot.
- `requirements.txt`: Environment dependencies.

## Instructions to Run

### Setup Virtual Environment
```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# Linux/macOS:
source .venv/bin/activate
pip install -r requirements.txt
```

### Running Tasks
1. **Task 1 - Tokenization & FAQ Bot:**
   ```bash
   python task1_tokens.py
   python task1_chatbot_check.py
   python guided_chatbot.py --backend embedding
   ```

2. **Task 2 - Chunking Module & Tests:**
   ```bash
   python task2_chunks.py
   ```

3. **Task 3 - Evaluation & Interactive Chatbot:**
   ```bash
   python task3_retrieval.py
   python document_chatbot.py
   ```
