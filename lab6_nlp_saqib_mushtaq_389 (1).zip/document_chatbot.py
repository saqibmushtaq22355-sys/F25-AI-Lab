import json
from task2_chunks import make_chunks
from lab6_search import Retriever

if __name__ == "__main__":
    with open("corpus.json", encoding="utf-8") as f:
        docs = json.load(f)
    engine = Retriever(make_chunks(docs, "sentence"), "embedding")
    print("Evidence assistant. Type exit to stop.")
    while True:
        try:
            query = input("Question: ")
        except (EOFError, KeyboardInterrupt):
            break
        if query.strip().lower() == "exit":
            break
        hits = engine.search(query)
        if not hits:
            print("No candidate evidence; rephrase or contact a human.")
            continue
        print("\nCandidate evidence; relevance must be checked:")
        for number, (r, score) in enumerate(hits, 1):
            print(f"{number}. ID: {r['id']} (Score: {score:.3f}, Chars: [{r['start']}:{r['end']}])")
            print(f"   Excerpt: {r['text'][:80]}...")
        chosen = input("Choose 1-3 to inspect; Enter if none apply: ")
        if not chosen.isdigit() or not 1 <= int(chosen) <= len(hits):
            print("No answer selected. Rephrase or contact a human.\n")
            continue
        r, score = hits[int(chosen) - 1]
        print("\n--- RETRIEVED EVIDENCE PASSAGE ---")
        print("Passage:", r["text"])
        print(f"Source Document: {r['doc']} (Characters {r['start']}:{r['end']})")
        print("-" * 35 + "\n")
