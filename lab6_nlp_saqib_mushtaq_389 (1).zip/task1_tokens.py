"""
Student Name: Saqib Mushtaq Ahmed
Roll Number: 389
Course: AI Lab CS4944 (Lab 6 Task 1)
"""
import re

samples = [
    "AI, search!", 
    "I can't log in.", 
    "help@example.com",
    "CS4944 version 2.1", 
    "", 
    "یہ ایک مثال ہے"
]

print("=== TASK 1: TOKENIZATION COMPARISON ===")
print("Student: Saqib Mushtaq Ahmed | Roll No: 389\n")

for text in samples:
    ws = text.split()
    words = re.findall(r"\b\w+\b", text, flags=re.UNICODE)
    print(f"Original: {repr(text)}")
    print(f"  Whitespace ({len(ws)}): {ws}")
    print(f"  Word-like  ({len(words)}): {words}")
    print("-" * 50)

try:
    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2", device="cpu")
    print("\n=== MODEL SUBWORD TOKENIZER (MiniLM-L6-v2) ===")
    for text in samples[:4]:
        tokens = model.tokenizer.tokenize(text)
        print(f"Text: {repr(text)}")
        print(f"  Subwords ({len(tokens)}): {tokens}")
except Exception as e:
    print(f"Model tokenizer skipped or error: {e}")
